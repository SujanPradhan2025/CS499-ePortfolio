package com.example.yourweighthero;

import androidx.appcompat.app.AppCompatActivity;
import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class DashboardActivity extends AppCompatActivity {

    SQLiteDatabase db;
    EditText weightInput;
    Button addWeightButton, deleteWeightButton, updateWeightButton, viewWeightButton;
    TextView weightDisplay;
    private static final int SMS_PERMISSION_CODE = 101; // Permission request code

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        weightInput = findViewById(R.id.weightInput);
        addWeightButton = findViewById(R.id.addWeightButton);
        deleteWeightButton = findViewById(R.id.deleteWeightButton);
        updateWeightButton = findViewById(R.id.updateWeightButton);
        viewWeightButton = findViewById(R.id.viewWeightButton);
        weightDisplay = findViewById(R.id.weightDisplay);

        // Create or open the database
        db = openOrCreateDatabase("YourWeightHeroDB", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS weights(date TEXT, weight FLOAT);");

        // Add weight entry
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeight();
            }
        });

        // Delete weight entry
        deleteWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteWeight();
            }
        });

        // Update weight entry and send SMS if permission is granted
        updateWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateWeight();
            }
        });

        // View weight entries
        viewWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewWeights();
            }
        });

        // Check if SMS permission is granted, if not, request it
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    private void addWeight() {
        String weight = weightInput.getText().toString();
        db.execSQL("INSERT INTO weights VALUES(date('now'), ?)", new String[]{weight});
        Toast.makeText(this, "Weight Added", Toast.LENGTH_SHORT).show();
    }

    private void deleteWeight() {
        db.execSQL("DELETE FROM weights WHERE date = date('now')");
        Toast.makeText(this, "Weight Deleted", Toast.LENGTH_SHORT).show();
    }

    private void updateWeight() {
        String newWeight = weightInput.getText().toString();
        db.execSQL("UPDATE weights SET weight = ? WHERE date = date('now')", new String[]{newWeight});
        Toast.makeText(this, "Weight Updated", Toast.LENGTH_SHORT).show();

        // Send SMS notification if permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSMSNotification("Your weight has been updated to: " + newWeight + " kg.");
        } else {
            Toast.makeText(this, "SMS permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    private void viewWeights() {
        Cursor cursor = db.rawQuery("SELECT * FROM weights", null);
        StringBuilder builder = new StringBuilder();

        while (cursor.moveToNext()) {
            String date = cursor.getString(0);
            String weight = cursor.getString(1);
            builder.append("Date: ").append(date).append(", Weight: ").append(weight).append("\n");
        }

        weightDisplay.setText(builder.toString());
    }

    // Function to send SMS notification
    private void sendSMSNotification(String message) {
        String phoneNumber = "RECIPIENT_PHONE_NUMBER"; // Replace with actual recipient phone number
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();
    }

    // Handle SMS permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
