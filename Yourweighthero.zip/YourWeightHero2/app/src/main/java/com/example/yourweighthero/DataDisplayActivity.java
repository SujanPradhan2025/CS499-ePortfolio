package com.example.yourweighthero;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private DataAdapter dataAdapter;
    private List<WeightData> weightDataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.data_display_activity);

        recyclerView = findViewById(R.id.dataRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        weightDataList = new ArrayList<>();
        weightDataList.add(new WeightData("2024-10-05", 150, 10));
        weightDataList.add(new WeightData("2024-10-12", 145, 8));

        dataAdapter = new DataAdapter(weightDataList);
        recyclerView.setAdapter(dataAdapter);

        // Add Data Button logic
        Button addDataButton = findViewById(R.id.addDataButton);
        addDataButton.setOnClickListener(v -> {
            // Add new data logic (future implementation)
        });
    }
}
