package com.example.yourweighthero;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase db;
    EditText usernameEditText, passwordEditText;
    Button loginButton, createAccountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameEditText = findViewById(R.id.usernameEditText); // Username input
        passwordEditText = findViewById(R.id.passwordEditText); // Password input
        loginButton = findViewById(R.id.loginButton); // Button to log in
        createAccountButton = findViewById(R.id.createAccountButton); // Button to create a new account

        // Create or open the SQLite database
        db = openOrCreateDatabase("YourWeightHeroDB", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS users(username TEXT, password TEXT);");

        // Handle login button click
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loginUser(); // Function to log in
            }
        });

        // Handle create account button click
        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createUserAccount(); // Function to create a new account
            }
        });
    }

    // Function to login the user
    private void loginUser() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Query the database to check if the user exists
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username=? AND password=?", new String[]{username, password});
        if (cursor.getCount() > 0) {
            // If the credentials match, navigate to the dashboard
            Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
            startActivity(intent);
        } else {
            // Show an error if the credentials are incorrect
            Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
        }
    }

    // Function to create a new user account
    private void createUserAccount() {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Insert the new user into the database
        db.execSQL("INSERT INTO users VALUES(?, ?)", new String[]{username, password});
        Toast.makeText(this, "Account Created", Toast.LENGTH_SHORT).show();
    }
}
